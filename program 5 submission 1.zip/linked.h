// Aaron Baker, Cs162 (Karla Fant) 3/10/2022
//Program 5 
//Linked-List of Athletes 
// Program that is an update of the previous registry of athletes.
// This program seeks to allow for the input and output of values corresponding to entered athletes in an orderly
// fashion using linked lists. Functions for a node struct, such as 
// push have been implemented as well as a destructor and function for re-initializing the list


#include <iostream> // for input output
#include <cctype> // for comparisons in later implementation
#include <iomanip> // for column formatting in later implementations
#include <cstring> // for string comprehensions.
using namespace std;

const int size_n = 50;

struct athlete{
    char name[size_n]{"america"}; // first and last name
    char sport[size_n]{}; // what sport they play
    int medals{0}; // number of medals an athlete has
    int age{}; // age of athlete
    char fb_link[size_n]{}; // unrealistic size for a link, but otherwise would be messy/wasteful
    char city[size_n]{}; // Home city of athlete
    char country[size_n]{}; // country of athlete
};

struct node{
    athlete data;
    node * next;
};

struct linked_list{
    node * head = new node;
};

class Olympic{
    public:
        Olympic(int num_aths);
        int my_aths;
        linked_list my_list;
        void create_list();
        //void read_new(); // Not used in program, can be used to reinitialize head for bench testing.
        node * node_push(node * &current);
        void change_chars(char entry[],char entry_type[]);
        void change_data(node *&node_edit);
        void display_values(node *my_node);
        void fix_case(char entry[]); //used to change entry to proper case
        void display_match();
        void display_out(athlete temp_ath[], int width);
};

