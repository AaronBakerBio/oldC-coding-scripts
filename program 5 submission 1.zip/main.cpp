// Aaron Baker (Karla Fant) Cs162 3/10/2022
// Program 5 submission 1
// Description can be found in linked.h
// This file executes class functions to create the menu shown
// to the user in the registry of athletes

#include "linked.h"

int registry_maker(); // Function that validates entries for the number of athletes to add
void menu(); // function that handles the registry function and class instances


int main() {
    menu();
    return 0;
}

void menu(){
    int count;

    // main body of menu
    count = registry_maker();
    Olympic my_reg(count);
}

int registry_maker(){
    int num_athletes{0}; // number of athlete's to be made
    int looper{0}; // loop for num_athletes entry to prevent illegal entries
    cout << "Welcome to the olympic athlete registry program!\n";
    while (0 == looper){
        cout << "Please enter the number of athletes you would like to enter:";
        cin >> num_athletes;
        cin.ignore(100,'\n');
        if (cin.fail()){
            cin.clear();
            cin.ignore(100, '\n');
            cout << "Please do not enter non-numerics\n\n";
        }
        else{
            if (num_athletes > 0){
                ++looper;
            }
            else {
                cout << "Please enter a positive integer value\n";
            }
        }
    }
    return num_athletes;
}
