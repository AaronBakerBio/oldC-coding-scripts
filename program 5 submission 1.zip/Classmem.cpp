#include "linked.h"
// initializes ll with head as null
Olympic::Olympic(int num_aths) {
    my_list.head -> next = nullptr;
    delete my_list.head -> next;
    my_list.head = nullptr;
    delete my_list.head;
    for (int i = 0; i < num_aths; ++i){
        cout << "Please enter the value for athlete " << i+1 << endl;
        create_list();
    }
    int my_aths = num_aths;
}

void Olympic::create_list() {
    node * current;
    current = my_list.head;
    if (!my_list.head){
    node_push(current);
    my_list.head = current;}
    else{
        node_push(current);
    }
    current = nullptr;
    delete current;
}
// can be used to re-initialize head, basically destroy linked list
//void Olympic::read_new(){
//    if (my_list.head) {
//        while (my_list.head != nullptr) {
//            my_list.head = my_list.head->next;
//        }
//        my_list.head = nullptr;
//        delete my_list.head;
//    }
//}

// pushes value to front
node * Olympic::node_push(node * &current) {
    node * new_head = new node;
    new_head -> next = current;
    change_data(new_head);
    current = new_head;
    return current;
}

void Olympic::change_data(node *&node_edit){
    node * new_data = node_edit;
    char w[][15]{"name", "sport", "medals", "age", "fb_link", "city", "country"};
    change_chars(new_data->data.name,w[0]);
    change_chars(new_data->data.sport, w[1]);
    change_chars(new_data->data.fb_link, w[4]);
    change_chars(new_data->data.city, w[5]);
    change_chars(new_data->data.country, w[6]);
}

// This function used to update a character array entry of an athlete
// object instance.
void Olympic::change_chars(char entry[],char entry_type[]){
    char add_break{}; // break loop for adding entries
    int looper{0}; // variable for looping user entry
    char new_entry[size_n];
    do {
        add_break = 'b';
        cout << "Please enter the " << entry_type;
        cin.get(new_entry,size_n);
        fix_case(new_entry);
        cin.ignore(100,'\n');
        while (add_break !='y' && add_break != 'n'){
        cout << "Is the entry: " << new_entry << " correct?(y/n)\n";
        cin >> add_break;
        cin.ignore(100,'\n');
        if (add_break == 'y'){
            strcpy(entry,new_entry);
            ++looper;
        }
        else if (add_break == 'n'){
            cout << "Please enter a new value\n";
        }}
    }
    while (looper == 0);
}

// Used to prevent user for putting a lowercase for the first part of the array
// Will only change value if alphabet character, however doesn't delete leading
// whitespace, a goal of later implementations
void Olympic::fix_case(char entry[]){
    int count{0};
    for (int position = 0; position < size_n; ++position){
        if (isalpha(entry[position]) != 0){
            if (count == 0){
                entry[position] = toupper(entry[position]);
                ++ count;
            }
            else{
                entry[position] = tolower(entry[position]);
            }
        }
    }
}

void Olympic::display_out(athlete temp_ath[], int width){
    for (int i = 0; i < my_aths; ++i){
        cout << setw(width) << temp_ath[i].name << setw(width) << temp_ath[i].sport << setw(width)
             << (temp_ath[i]).medals << setw(width) << temp_ath[i].age << setw(width) << temp_ath[i].fb_link
             << setw(width) << temp_ath[i].country << setw(width) << temp_ath[i].city << setw(width) <<endl;
    }
    cout << right << setw(0);
}