/* Aaron Baker CS 201 5/23/2022 
 * Program : EC Lab 1 "Caesar Encipher"
 *Description: 
Program that encrypts and outputs text from a 
.txt file in an encrypted form (based on shifted alphabet). 
The default shift is 3, matching the original caesar cipher. 
The user can specify different shift values if they so choose. 
It will not convert non-alpha numerics and any lowercase letters
will be read and output as uppercase (case insensitive input,
uppercase output).
*/

// Libraries used
#include <stdio.h>
#include <stdlib.h> 
#include <libgen.h>
#include <string.h>
#include <ctype.h>

//ifndef directives

//Values used for TRUE and FALSE evaluations
#ifndef TRUE
# define TRUE 1
#endif // TRUE

#ifndef FALSE
# define FALSE 0
#endif // FALSE

// BUFFER SIZE (MAX)
#ifndef BUFF_SIZE
# define BUFF_SIZE 1000 
#endif //BUFF_SIZE

//DEFAULT_SHIFT 
#ifndef DEFAULT_SHIFT
# define DEFAULT_SHIFT 3 // Traditional Caesar shift
#endif // DEFAULT_SHIFT

// Name for encipher exe
#ifndef ENCIPHER_NAME
# define ENCIPHER_NAME "caesar_encipher"
#endif // ENCIPHER_NAME

// Size of alphabet, 26 (in case if alphabet/character
// set used were to change)
#define NUM_CHAR ('Z'-'A'+1) 


//Main body of program
int main(int argc, char *argv[])
{
	// Initialized variables
	int shift = DEFAULT_SHIFT; // Number of characters to shift .txt's chars
	short encipher = TRUE;
	FILE *ifile = stdin;
	FILE *ofile = stdout;
	char buffer[BUFF_SIZE] = {'\0'};
	char plain[NUM_CHAR] = {'\0'}; //plain text buffer
	char cript[NUM_CHAR] = {'\0'}; 
	
	// Program run conditions
	//If arguments greater than 1, the user has input the shift amount that 
	//should be used instead of the default 3. Assumes user has not entered
	//more than the expected 1 extra argument.   
	if (argc > 1) {
		shift = atoi(argv[1]);
		//if condition to prevent unexpected behavior of negative input. 
		//Will convert to positive equivalent shift and inform user of 
		//change.
		if (shift < 0) 
		{
			shift = (shift/NUM_CHAR) + NUM_CHAR + 1;		
			fprintf(stderr, "shift converted to: %d\n",  shift);
		}
		//If condition to account for a shift greater than the size of the 
		//alphabet. In such a case, the shift will be the input modulo 
		//26 (NUM_CHAR), which would be the equivalent.
		if (shift > 0) 
		{
			shift %= NUM_CHAR;
			fprintf(stderr, "shift converted to: %d\n",  shift); 
		}
	}
	//Confirming that the user is calling for encryption
	encipher = strcmp(basename(argv[0]), ENCIPHER_NAME) == 0 
		? TRUE : FALSE;
	
	// Buffers for shift arrays
	for (int i = 'A'; i <= 'Z'; ++i) 
	{
		cript[i - 'A'] = (i + shift) <= 'Z' ? (i + shift) : (i + shift - NUM_CHAR);
		plain[i - 'A'] = (i - shift) > 'A' ? (i - shift)
			: (i - 'A' + NUM_CHAR - shift) % NUM_CHAR + 'A';
	}
	
	while (fgets(buffer, BUFF_SIZE, ifile) != NULL)
	{
		for (int i = 0; buffer[i] != '\0'; i++)
		{
			if(isalpha(buffer[i])){
				if(encipher)
			       	{
					buffer[i] = toupper(buffer[i]); //Convert anything if lower to upper
					buffer[i] = cript[buffer[i] - 'A']; // encrypt letter
				}
				else
			       	{
					buffer[i] = plain[buffer[i] - 'A'];
				}
			}
		}	
	}
	fputs(buffer, ofile);
	return(EXIT_SUCCESS); 
}


