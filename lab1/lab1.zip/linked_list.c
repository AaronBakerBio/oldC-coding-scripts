/*Aaron Baker, CS 201, Instructor : Jesse Chaney
Date: 4-15-2022 
Program: 
Description: Program that receives arguments for file names.
It iterates through files, line by line, assigning the lines as nodes in a linked list.
It then iterates through the linked list and prints the lines contained in the files.
*/

#include <string.h> // for strcpy
#include <stdio.h>
#include <stdlib.h> 

#include "linked_list.h" 
// Macros
#define MAX_LINE_LENGTH 1000

//This program requires a file name to be run on.
int main(int argc, char* argv[])
{
	FILE* iFile;
	char buffer[MAX_LINE_LENGTH] = {'\0'};	
	char * hold_word = NULL;
	list_t* my_list = NULL;
	my_list = (list_t*)malloc(sizeof(list_t));
	my_list -> head = NULL;	
	my_list -> tail = NULL;
	for (int i = 1; i < argc; ++i){	
	iFile = fopen(argv[i],"r");
	// Main body of program		
	hold_word = fgets(buffer, MAX_LINE_LENGTH, iFile);
	while(hold_word != NULL){
		node_t* temp_node0 = (node_t*)malloc(sizeof(node_t));
		temp_node0 -> line = strdup(hold_word);
		temp_node0 -> next = NULL;
		if (my_list -> head == NULL){
			my_list -> head = temp_node0;
			my_list -> tail = temp_node0;	
		}	
		else{
			my_list -> tail -> next = temp_node0;
			my_list -> tail = temp_node0;	
				
		}
		
		hold_word = fgets(buffer, MAX_LINE_LENGTH, iFile);

	}	
	}
	unsigned int line_count = 1;
	while(my_list -> head != NULL){
	printf("%03d: %s", line_count,my_list->head->line);	
	my_list -> head = my_list -> head -> next;
	++line_count;
	}
	free(my_list);
	fclose(iFile);
	
	return(EXIT_SUCCESS);
}
