/*Aaron Baker, CS 201, Instructor : Jesse Chaney
Date: 4-15-2022 
Program: Raggedy Array
Description: 
Program that utilizes the fgets functionality to 
grab lines from a file. This program grabs all lines of 
information (if a file is not empty) and stores them into a 
variable, which is later copied into a temporary array. It then
stores these values into the ragged array, whose values are printed
as output. */

#include <string.h> // for strcpy
#include <stdio.h>
#include <stdlib.h> 
// Macros
#define MAX_LINE_LENGTH 1000

//This program requires a file name to be run on.
int main(int argc, char* argv[])
{
	char** ragged_array = NULL;
	FILE *iFile = stdin;		
	char buffer[MAX_LINE_LENGTH] = {'\0'}; // Character array used to store a line from the file read in.
	char *grabline = NULL; // pointer to a line from the file being read in.
	int line_count = 0;
	grabline = fgets(buffer, MAX_LINE_LENGTH, iFile);	
	//To catch empty case, this line was included. 
	//To improve results visibility, extra newlines were included
//	if (grabline == NULL){
//		free(grabline);
//		printf("\n%s\n","File contains no data");
//		return 0;
//	}	
	//While loop allows for allocation of temporary array and passing of values to
	//the ragged array so long as linegrab does not have a NULL value.
	while(grabline != NULL){
		char **temp_arr = malloc((line_count+1)*sizeof(char*));

		
			for(unsigned int looper_num = 0; looper_num < line_count; looper_num++){
				temp_arr[looper_num] = ragged_array[looper_num];
			}
		free(ragged_array);
		ragged_array = temp_arr;
		ragged_array[line_count] = malloc((strlen(buffer)+1)*sizeof(char));
		strcpy(ragged_array[line_count],buffer);
		line_count +=1;
		grabline = fgets(buffer, MAX_LINE_LENGTH, iFile);
	}
	for(unsigned int i = 0; i < line_count;++i){
		printf("%.04d: %s",i,ragged_array[i]);
	}
	grabline = NULL;		
	for(unsigned int x = 0; x < line_count; ++x){
		free(ragged_array[x]);
	}
	free(ragged_array);
	return (EXIT_SUCCESS);
}

